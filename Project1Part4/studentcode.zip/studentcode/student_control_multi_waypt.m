% MEAM 620 Student Multi Waypoint code

if (setitM(qn)~=903) %The variable setitM(qn) tracks what type of sequence each quad is in. 
                     %If the quad switches sequences, this if statement will be active.
    setitM(qn)=903;  %This changes setitM(qn) to the current sequence type so that this code only runs once.
    
    %PUT ANY INITIALIZATION HERE
    t0 = GetUnixTime;
    params=nanoplus();
    load test_waypts_3.mat
    new_corners=[qd{qn}.pos'; waypts ];

    % Remove intermediate waypoints
%     pathopt = new_corners(1:2,:);
%     path = new_corners;
%     for i = 3:(size(path,1))
%         % Check if we are on a line
%         a = path(i,:) - pathopt(end,:);
%         b = pathopt(end,:) - pathopt(end-1,:);
%         if norm(a/norm(a) - b/norm(b)) < 10^-9
%             pathopt(end,:) = path(i,:);
%         else
%             pathopt = [ pathopt; path(i,:) ];
%         end
%     end
%     new_corners = pathopt;
    traj = create_spline(new_corners);
        
%     edge_lengths=sqrt(sum((new_corners(2:end,:)-new_corners(1:end-1,:)).^2,2));
%     some_constant=2; % 0.9
%     time_per_edge=some_constant*sqrt(edge_lengths);
% 
%     edge_timestamps=zeros(length(time_per_edge)+1,1);
%     for i=1:length(time_per_edge)
%         edge_timestamps(i+1)=sum(time_per_edge(1:i));
%     end
    
    
%     [m,n]=size(new_corners);
%     total_edges=m-1;
    
    %%%%
%     for edge_index=1:size(edge_timestamps)-1
%         bt=edge_timestamps(edge_index);
%         ft=edge_timestamps(edge_index+1);
% 
%         % calculate A matrix
%         A= [1,   bt, bt^2, bt^3, bt^4, bt^5;
%             0,   1,  2*bt, 3*bt^2, 4*bt^3, 5*bt^4;
%             0,   0,  2,  6*bt, 12*bt^2, 20*bt^3;
%             1,   ft, ft^2, ft^3, ft^4, ft^5;
%             0,   1,  2*ft, 3*ft^2, 4*ft^3, 5*ft^4;
%             0,   0,  2,  6*ft, 12*ft^2, 20*ft^3];
%         bx = [new_corners(edge_index,1);0;0;new_corners(edge_index+1,1);0;0];
%         by = [new_corners(edge_index,2);0;0;new_corners(edge_index+1,2);0;0];
%         bz = [new_corners(edge_index,3);0;0;new_corners(edge_index+1,3);0;0];
%         Cx{edge_index}= A\bx;
%         Cy{edge_index}= A\by;
%         Cz{edge_index}= A\bz;
%     end
    
    % For data collection
    % Columns: time, trpy, qd{qn}
    savedata = cell(100*600,3);
    i_data = 1;
    
    %END INTITIALIZATION

end %everything beyond this point runs every control loop iteration

%COMPUTE CONTROL HERE
% Time for this step
t = GetUnixTime - t0;

% edge_index=find(edge_timestamps>t,1)-1;
% if (isempty(edge_index))
%     pos=[new_corners(end,1);new_corners(end,2);new_corners(end,3)];
%     vel=[0;0;0];
%     acc=[0;0;0];
%     yaw=0;
%     yawdot=0;
%     
% else
% 
%     t1=[1, t, t^2, t^3, t^4, t^5];
%     t2=[0,   1,  2*t, 3*t^2, 4*t^3, 5*t^4];
%     t3=[0,   0,  2,  6*t, 12*t^2, 20*t^3];
%     
%     if edge_index<=total_edges
%         
%         ax=Cx{edge_index};
%         ay=Cy{edge_index};
%         az=Cz{edge_index};
%         % position
%         x=t1*ax;
%         y=t1*ay;
%         z=t1*az;
%         % velocity
%         x_dot=t2*ax;
%         y_dot=t2*ay;
%         z_dot=t2*az;
%         % acceleration
%         x_ddot=t3*ax;
%         y_ddot=t3*ay;
%         z_ddot=t3*az;
%     else
%         x=new_corners(end,1);
%         y=new_corners(end,2);
%         z=new_corners(end,3);
%         x_dot=0;
%         y_dot=0;
%         z_dot=0;
%         x_ddot=0;
%         y_ddot=0;
%         z_ddot=0;
%     end
%     
%     pos=[x;y;z];
%     vel=[x_dot;y_dot;z_dot];
%     acc=[x_ddot;y_ddot;z_ddot];
    yaw=0;
    yawdot=0;
%     
% end

if t < max(traj.T)
    qd{qn}.pos_des=traj.pos(t);
    qd{qn}.vel_des=traj.vel(t);
    qd{qn}.acc_des=traj.acc(t);
else
    qd{qn}.pos_des=new_corners(end,:)';
    qd{qn}.vel_des=[0,0,0]';
    qd{qn}.acc_des=[0,0,0]';
end
qd{qn}.yaw_des=yaw;
qd{qn}.yawdot_des=yawdot;


[trpy, drpy] = controller(qd, t, qn, params);

% Saving data
savedata{i_data,1} = t;
savedata{i_data,2} = trpy;
savedata{i_data,3} = qd{qn};
i_data = i_data + 1;



% MEAM 620 Student Hover code

if (setitM(qn)~=901) %The variable setitM(qn) tracks what type of sequence each quad is in. 
                     %If the quad switches sequences, this if statement will be active.
    setitM(qn)=901;  %This changes setitM(qn) to the current sequence type so that this code only runs once.
    
    %PUT ANY INITIALIZATION HERE
    % Columns: time, trpy, qd{qn}
    savedata = cell(100*600,3);
    i_data = 1;
    t0 = GetUnixTime;
    params=nanoplus();
    
    qd{qn}.vel_des=[0;0;0];
    qd{qn}.acc_des=[0;0;0];
    qd{qn}.yaw_des=0;
    qd{qn}.yawdot_des=0;
    qd{qn}.pos_des=qd{qn}.pos;
    
    %END INTITIALIZATION

end %everything beyond this point runs every control loop iteration

%COMPUTE CONTROL HERE

t = (GetUnixTime - t0);
[trpy, drpy] = controller(qd, t, qn, params);
savedata{i_data,1} = t;
savedata{i_data,2} = trpy;
savedata{i_data,3} = qd{qn};
i_data = i_data + 1;



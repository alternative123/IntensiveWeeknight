function [trpy, drpy] = controller(qd, t, qn, params)
% CONTROLLER quadrotor controller
% The current states are:
% qd{qn}.pos, qd{qn}.vel, qd{qn}.euler = [roll;pitch;yaw], qd{qn}.omega
% The desired states are:
% qd{qn}.pos_des, qd{qn}.vel_des, qd{qn}.acc_des, qd{qn}.yaw_des, qd{qn}.yawdot_des
% Using these current and desired states, you have to compute the desired controls

% =================== Your code goes here ===================

% some parameters here
m= params.mass;
g=params.grav ;

% Desired roll, pitch and yaw

% these are better
Kp_pos = 10*[1;1;1];
Kd_pos =  5*[1;1;1];
Kpatt = 1.5*ones(3,1);
Kdatt = 0.15*ones(3,1);



acc_c =  qd{qn}.acc_des + ...
         Kd_pos.*(qd{qn}.vel_des - qd{qn}.vel)+...
         Kp_pos.*(qd{qn}.pos_des - qd{qn}.pos);

phi_c = (1/g)*(  acc_c(1)*sin(qd{qn}.yaw_des) - ...
                 acc_c(2)*cos(qd{qn}.yaw_des)  );
              
theta_c = (1/g)*( acc_c(1)*cos(qd{qn}.yaw_des) + ...
                  acc_c(2)*sin(qd{qn}.yaw_des)  );
                
psi_des = qd{qn}.yaw_des;
                
p_c = 0;
q_c = 0;
r_des = qd{qn}.yawdot_des;




phi = qd{qn}.euler(1);
theta = qd{qn}.euler(2);
psi = qd{qn}.euler(3);

p = qd{qn}.omega(1);
q = qd{qn}.omega(2);
r = qd{qn}.omega(3);


u2 =   Kpatt.*[phi_c-phi ; theta_c-theta; psi_des-psi] + ...
       Kdatt.*[p_c-p ;q_c-q ;r_des-r];

u1 = m*g + m*acc_c(3); 



% Thurst
F=min(params.maxF,max(params.minF,u1));


%F = m*g; % hold it at least

% Moment
M = u2;
%M    = zeros(3,1); % You should fill this in



phi_des = phi_c;
theta_des = theta_c;

% max angle
phi_des=sign(phi_des)*min(abs(phi_des),params.maxangle);
theta_des=sign(theta_des)*min(abs(theta_des),params.maxangle);


% convert Force to appropriate units
thrust=1000*(F/params.grav);

% =================== Your code ends here ===================

% Output trpy and drpy as in hardware
trpy = [thrust, phi_des, theta_des, psi_des];
drpy = [0, 0,       0,         0];

end
